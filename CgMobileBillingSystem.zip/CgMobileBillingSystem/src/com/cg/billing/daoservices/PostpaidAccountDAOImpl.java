package com.cg.billing.daoservices;

import java.util.List;

import com.cg.billing.beans.PostpaidAccount;

public class PostpaidAccountDAOImpl implements PostpaidAccountDAO{

	@Override
	public PostpaidAccount save(PostpaidAccount postpaidAccount) {
		
		return null;
	}

	@Override
	public boolean update(PostpaidAccount postpaidAccount) {
		
		return false;
	}

	@Override
	public PostpaidAccount findOne(long mobileNo) {
		
		return null;
	}

	@Override
	public List<PostpaidAccount> findAll() {
		
		return null;
	}

}
