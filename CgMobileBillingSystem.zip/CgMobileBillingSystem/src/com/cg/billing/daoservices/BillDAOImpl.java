package com.cg.billing.daoservices;

import java.util.List;

import com.cg.billing.beans.Bill;

public class BillDAOImpl implements BillDAO{

	@Override
	public Bill save(Bill bill) {

		return null;
	}

	@Override
	public boolean update(Bill bill) {
		
		return false;
	}

	@Override
	public Bill findOne(long billId) {
		
		return null;
	}

	@Override
	public List<Bill> findAll() {
		
		return null;
	}

}
