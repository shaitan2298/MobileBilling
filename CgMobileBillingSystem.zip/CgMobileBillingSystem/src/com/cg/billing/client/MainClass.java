package com.cg.billing.client;

import com.cg.billing.daoservices.PlanDAO;
import com.cg.billing.daoservices.PlanDAOImpl;

public class MainClass {
	

	
	public static void main(String[] args) 
	{
		

	}

}
